﻿namespace OptiSol.MSAzure {
    public class ConstantString {
        public enum EnumYesOrNo {
            Yes = 1,
            No = 0
        }
    }
}
